import React from "react";
import ReactDOM from "react-dom";
import { Header } from "./components/Header";
import { Home } from "./components/Home";
// import { Vacancy } from "./components/Vacancy";

class App extends React.Component {
    render(){

        let user = {
            firstName: "Mario",
            lastName: "Petkovski",
            age: 24,
            hobbies: ["Eating", "Sleeping", "Coding"]
        };

        let numbers = {
            a: 10,
            b: 5
        }

        let weather = [
            {
                day: "mon",
            },
            {
                day: "tue"
            },
            {
                day: "wed"
            },
            {
                day: "thr"
            },
            {
                day: "fri"
            },
            {
                day: "sat"
            },
            {
                day: "sun"
            }
        ]

        return(
            <div>
                <Header />
                <Home weather={weather} multiply={numbers} greeting={"Hello World"} year={2018} user={user}>
                    <p>Passed NOT from props</p>
                </Home>
                {/* <Vacancy hasVacancy={true} /> */}
            </div>
        );
    }
}

ReactDOM.render(<App/>, document.getElementById("root"));