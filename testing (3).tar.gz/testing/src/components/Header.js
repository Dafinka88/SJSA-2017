import React from "react";

export const Header = (props) => {
        return(
            <div>
                <h2>This comes from Header</h2>
            </div>
        )
 }