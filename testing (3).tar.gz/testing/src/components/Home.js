 import React from "react";
 import PropTypes from "prop-types";
//  import { Comments } from "./Comments";

 export class Home extends React.Component {

    constructor(props){
        super();
        this.state = {
            age: props.user.age,
            num_01: props.multiply.a,
            num_02: props.multiply.b,
            status: 0,
            color: "",
            currentDay: ""
        }

        setTimeout(() => {
            this.setState({
                status: 1
            });
        }, 3000);
    }

    changeColor(){
        this.setState({
            color: "red"
        });
    }

    calculate(){
        this.setState({
            result: this.state.num_01 * this.state.num_02
        })
    }

    makeOlder(){ 
        this.setState({
            age: this.state.age + 3
        })
    }   

    getDay(d){
        this.setState({
            currentDay: d.day
        });
        console.log(d);
    }

    render(){
        return(
            <div>
                <h2>This comes from Home</h2>

                <hr/>

                <h2>My age is {this.state.age}</h2>
                <button onClick={this.makeOlder.bind(this)}>Make me older</button>

                <h2>Number are {this.state.num_01} &amp; {this.state.num_02} and the result is {this.state.result}</h2>

                <button onClick={this.calculate.bind(this)}>Calculate</button>

                
                <hr/> 
                
                <h2>Status is: {this.state.status}</h2>


                <hr />
                <br/>
                <button onClick={this.changeColor.bind(this)}>Change Color</button>
                <h2 style={{color: this.state.color}}>Mario Petkovski</h2>

                <ul>
                    {this.props.weather.map((d, i) => 
                        <li onClick={() => this.getDay(d)} key={i}>{d.day}</li>    
                    )}
                </ul>

                <h2>Day is: {this.state.currentDay}</h2>

                {/* <h2>{this.props.greeting}, the year is {this.props.year}.</h2> */}

                {/* <h2>Hello user: => {this.props.user.firstName} {this.props.user.lastName}. Your age is {this.props.user.age}.</h2>

                <hr />

                <ul>
                    {this.props.user.hobbies.map((hobby, i) => 
                        <li key={i}>{hobby}</li>    
                    )}
                </ul>
                
                <hr/>

                {this.props.children}
                
                <Comments data={comments} /> */}
            </div>
         );
     }
 }

 Home.propTypes = {
     greeting: PropTypes.string,
     year: PropTypes.number,
     user: PropTypes.object,
     children: PropTypes.element.isRequired
 }