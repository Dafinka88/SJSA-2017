import React from "react";

export class Header extends React.Component {
    render(){
        return(
            <h2>This comes from Header</h2>
        );
    }
}