import React from "react";

export class Comments extends React.Component {
	render(){
		return(
			<ul className="comment_list">
				<li>
					<a href="#">Pero Perovski</a>
					<p>This is an example of a comment</p>
				</li>
				<li>
					<a href="#">Pero Perovski</a>
					<p>This is an example of a comment</p>
				</li>
				<li>
					<a href="#">Pero Perovski</a>
					<p>This is an example of a comment</p>
				</li>
				<li>
					<a href="#">Pero Perovski</a>
					<p>This is an example of a comment</p>
				</li>
			</ul>
		);
	}
}